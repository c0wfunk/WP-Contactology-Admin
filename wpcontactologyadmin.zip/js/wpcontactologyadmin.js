jQuery(document).ready(function(){

	//functions to manage loading graphic
	function showLoading() {
		jQuery("#loading").show();
	}
	function hideLoading() {
		jQuery("#loading").hide();
	}	
	
	jQuery('#wp_contactology_new_client_submit').click( function() {
			
		showLoading();
		
		//gather variables
		var wpcntlgy_admin_client_name = jQuery('#wp_contactology_admin_client_name').val();
		var wpcntlgy_admin_client_email = jQuery('#wp_contactology_admin_email').val();
		var wpcntlgy_admin_client_username = jQuery('#wp_contactology_admin_username').val();
		var wpcntlgy_admin_client_password = jQuery('#wp_contactology_admin_password').val();
		
		
				
		//organize data for wp ajax request
		var data = {
			'action': 'wp_contactology_admin',
			'type': 'client_setup',
			'client_name': wpcntlgy_admin_client_name,
			'client_email': wpcntlgy_admin_client_email,
			'client_username': wpcntlgy_admin_client_username,
			'client_password': wpcntlgy_admin_client_password
		}
				
		//send data to admin-ajax.php
		jQuery.post(
			ajaxurl, //global variable that points to admin-ajax.php
			data, 
			function(response)  {
				hideLoading();
				jQuery('#wp_contactology_client_setup_results').html(response.message);
				//alert('The server responded: ' + response.message);

			}, "json"
		);
		
		return false;
			
	
	}); //end click function
			
	//click function that downloads file and initiates wp ajax handler
	jQuery('#wp_contactology_copy_folder_submit').click( function() {
	
		showLoading();
		
		//gather variables
		var wpcntlgy_admin_folder_id = jQuery('#wp_contactology_folder').val();
		var wpcntlgy_admin_folder_name = jQuery('#wp_contactology_folder option:selected').html();
		var wpcntlgy_admin_client = jQuery('#wp_contactology_client').val();
		var wpcntlgy_admin_list = jQuery('#wp_contactology_list').val();
		
				
		//organize data for wp ajax request
		var data = {
			'action': 'wp_contactology_admin',
			'type': 'copy_folder',
			'folder_id': wpcntlgy_admin_folder_id,
			'folder_name': wpcntlgy_admin_folder_name,
			'client': wpcntlgy_admin_client,
			'list': wpcntlgy_admin_list
		}
				
		//send data to admin-ajax.php
		jQuery.post(
			ajaxurl, //global variable that points to admin-ajax.php
			data, 
			function(response)  {
				hideLoading();
				jQuery('#wp_contactology_results').html(response.message);
				//alert('The server responded: ' + response.message);

			}, "json"
		);
		
		return false;
	}); //end click function
	
	//Watches clients dropdown and then populates and enables folders dropdown
	jQuery('#wp_contactology_admin_client').change( function() {
	
		showLoading();
		
		//gather variables
		var wpcntlgy_admin_folder_id = jQuery('#wp_contactology_folder').val();
		var wpcntlgy_admin_folder_name = jQuery('#wp_contactology_folder').attr('name');
		var wpcntlgy_admin_client = jQuery('#wp_contactology_admin_client').val();
		var wpcntlgy_admin_folder_name = jQuery('#wp_contactology_admin_client').attr('name');
		
				
		//organize data for wp ajax request
		var data = {
			'action': 'wp_contactology_admin',
			'type': 'get_lists',
			'folder_id': wpcntlgy_admin_folder_id,
			'client': wpcntlgy_admin_client
		}
				
		//send data to admin-ajax.php
		jQuery.post(
			ajaxurl, //global variable that points to admin-ajax.php
			data, 
			function(response)  {
				
				//enable the mailing list dropdown and populate with results
				jQuery('#wp_contactology_admin_list').prop('disabled', false).html(response.message);
				hideLoading();

			}, "json"
		);
		
		return false;
	}); //end click function

}); // end document ready function
